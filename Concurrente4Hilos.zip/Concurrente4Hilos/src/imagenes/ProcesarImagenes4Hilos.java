package imagenes;


import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class ProcesarImagenes4Hilos {

    public static void main(String[] args) {

        try {
            // === MEDIR TIEMPO ===
            long inicioTiempo = System.currentTimeMillis();

            // === 1. Cargar imágenes ===
            File carpeta = new File("C:\\Users\\LIZ\\Desktop\\Neatbeans\\imagenes\\Imagenes");
            File[] archivos = carpeta.listFiles((dir, name) ->
                name.toLowerCase().endsWith(".png") ||
                name.toLowerCase().endsWith(".jpg") ||
                name.toLowerCase().endsWith(".jpeg")
            );

            if (archivos == null || archivos.length == 0) {
                System.out.println("No hay imagenes disponibles.");
                return;
            }

            System.out.println("Total de imagenes encontradas: " + archivos.length);

            // === 2. Carpeta de salida ===
            File salida = new File("imagenes_grises_concurrente");
            if (!salida.exists()) salida.mkdirs();

            // === 3. DIVIDIR EN 4 RANGOS ===
            int total = archivos.length;   // Ej: 100
            int rango = total / 4;         // 25

            Thread[] hilos = new Thread[4];

            for (int i = 0; i < 4; i++) {

                int inicio = i * rango;
                int fin = (i == 3) ? total - 1 : (inicio + rango - 1);

                int inicioFinal = inicio;
                int finFinal = fin;

                hilos[i] = new Thread(() -> {

                    for (int j = inicioFinal; j <= finFinal; j++) {
                        try {
                            File imgFile = archivos[j];
                            BufferedImage imagen = ImageIO.read(imgFile);

                            // Procesar imagen COMPLETA con FiltroGris
                            new FiltroGris(imagen, 0, imagen.getHeight()).run();

                            File salidaImagen = new File("imagenes_grises_concurrente/" + imgFile.getName());
                            ImageIO.write(imagen, "png", salidaImagen);

                            System.out.println(Thread.currentThread().getName() +
                                               " proceso: " + imgFile.getName());

                        } catch (Exception e) {
                            System.out.println("Error procesando imagen " + archivos[j].getName());
                            e.printStackTrace();
                        }
                    }

                }, "Hilo-" + (i + 1));

                hilos[i].start();
            }

            for (Thread h : hilos) h.join();

            // === TIEMPO FINALIZADO ===
            long finTiempo = System.currentTimeMillis();
            long tiempoTotal = finTiempo - inicioTiempo;

            System.out.println("\n===== PROCESO COMPLETADO =====");
            System.out.println("Tiempo total: " + tiempoTotal + " ms (" + (tiempoTotal / 1000.0) + " s)");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
