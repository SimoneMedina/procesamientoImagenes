/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package imagenes;

import java.awt.image.BufferedImage;

public class FiltroGris implements Runnable {

    private final BufferedImage imagen;
    private final int inicioFila;
    private final int finFila;

    public FiltroGris(BufferedImage imagen, int inicioFila, int finFila) {
        this.imagen = imagen;
        this.inicioFila = inicioFila;
        this.finFila = finFila;
    }

    @Override
    public void run() {
        for (int y = inicioFila; y < finFila; y++) {
            for (int x = 0; x < imagen.getWidth(); x++) {

                int pixel = imagen.getRGB(x, y);

                int a = (pixel >> 24) & 0xff;  // canal alfa
                int r = (pixel >> 16) & 0xff;
                int g = (pixel >> 8) & 0xff;
                int b = pixel & 0xff;

                int gris = (r + g + b) / 3;

                // Mantener alfa
                int nuevoPixel = (a << 24) | (gris << 16) | (gris << 8) | gris;

                imagen.setRGB(x, y, nuevoPixel);
            }
        }
    }
}
